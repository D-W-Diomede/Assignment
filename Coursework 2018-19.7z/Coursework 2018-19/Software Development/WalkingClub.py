class members: # Class for storing member data

    def __init__(self,fname="",sname="",distance=0.0): 
        self.fname = fname #Stores member firstname onto one variable
        self.sname = sname #Stores member surname onto one variable
        self.distance = distance #Stores member distance onto one variable
        
            

def getMemberData(): #Reads member data from members.txt
    memberData=[]
    import csv #Imports comma seperated values module for use
    with open('members.txt','r') as data: # Opens members.txt
        memberinfo=csv.reader(data,delimiter=',') #CSV settings
        for row in memberinfo:
            memberData.append(members(row[0],row[1],float(row[2]))) #Reads data & stores data
        data.close() #Closes the file
        return memberData

def maxDistanceWalked(memberData): #Calculates the max distance from the data
    maxDistance=memberData[0].distance # Sets max distance to first instance of data
    for x in range(len(memberData)):
        if memberData[x].distance>maxDistance:
                maxDistance = memberData[x].distance #Re-assigns new max value
    return maxDistance

def showMaxDistance(maxDistance): #Prints max distance out
    print("\nThe maximum distance walked is {}".format(maxDistance))

def createResults(memberData,maxDistance): #Creates and writes to the new results file
    with open('results.txt','w') as resultsfile: #Opens new results.txt file
        resultsfile.write("The Prize Winning Members are:\n\n") #Writes heading to file
        for x in range(len(memberData)):
            if memberData[x].distance > 0.7*maxDistance:
                #Writes data to new file
                resultsfile.write("{}{}".format(memberData[x].fname,memberData[x].sname.rjust(15)))
                resultsfile.write("\n")

        resultsfile.write("\nWhole Number of Marathons Walked by Each Member is\n\n")
        for x in range(len(memberData)):
            marathons = memberData[x].distance // 26.22 #Calculates total marathons ran by member based on distance traveled
            #Writes data to new file
            resultsfile.write("{}\t{}\t{}".format(memberData[x].fname,memberData[x].sname.rjust(15),int(marathons)))
            resultsfile.write("\n")
        resultsfile.close()#closes new file

        
#Top-level program
memberdata=getMemberData()
maxDistance=maxDistanceWalked(memberdata)
showMaxDistance(maxDistance)
createResults(memberdata,maxDistance)
